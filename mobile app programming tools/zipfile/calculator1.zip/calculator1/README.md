# Description
Calc is simple calculator app created using Ionic Framework.

#Running
Navigate to calc folder and run 'ionic serve', the application then opens in a browser.

If you have not ionic installed, here is how to install it: http://ionicframework.com/getting-started/.
